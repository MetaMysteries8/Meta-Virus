Read Me
This is a virus meant to crash computers and take up space, do not use unless you are using a vm like vmware, thank you for understanding, Use this malware to your heart's content!